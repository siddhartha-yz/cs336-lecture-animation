sources = [
  'pygboxed.c',
  'pygenum.c',
  'pygflags.c',
  'pyginterface.c',
  'pygobject-class.c',
  'pygobject-object.c',
  'pygobject-props.c',
  'pygpointer.c',
  'pygspawn.c',
  'gimodule.c',
  'pygi-capi.c',
  'pygi-repository.c',
  'pygi-info.c',
  'pygi-foreign.c',
  'pygi-struct.c',
  'pygi-source.c',
  'pygi-argument.c',
  'pygi-resulttuple.c',
  'pygi-async.c',
  'pygi-type.c',
  'pygi-boxed.c',
  'pygi-closure.c',
  'pygi-ccallback.c',
  'pygi-util.c',
  'pygi-property.c',
  'pygi-signal-closure.c',
  'pygi-invoke.c',
  'pygi-cache.c',
  'pygi-cache-array.c',
  'pygi-cache-basic.c',
  'pygi-cache-closure.c',
  'pygi-cache-enum.c',
  'pygi-cache-error.c',
  'pygi-cache-hashtable.c',
  'pygi-cache-interface.c',
  'pygi-cache-list.c',
  'pygi-cache-object.c',
  'pygi-cache-struct.c',
  'pygi-marshal-cleanup.c',
  'pygi-basictype.c',
  'pygi-error.c',
  'pygi-fundamental.c',
  'pygi-value.c',
]

headers = [
  'pygobject.h',
  'pygobject-types.h'
]

install_headers(headers, subdir : 'pygobject-@0@'.format(platform_version))

python_sources = [
  'events.py',
  '_constants.py',
  'docstring.py',
  '_enum.py',
  '_error.py',
  '_gtktemplate.py',
  'importer.py',
  '__init__.py',
  'module.py',
  '_ossighelper.py',
  '_propertyhelper.py',
  '_signalhelper.py',
  '_signature.py',
  'types.py',
]

python.install_sources(python_sources,
  pure : false,
  subdir : 'gi'
)

# https://github.com/mesonbuild/meson/issues/4117
if host_machine.system() == 'windows'
  python_ext_dep = python_dep
else
  python_ext_dep = python_dep.partial_dependency(compile_args: true)
endif

configure_file(output : 'config.h', configuration : cdata)

giext = python.extension_module('_gi', sources,
  dependencies : [python_ext_dep, glib_dep, gi_dep, ffi_dep, pythoncapi_compat_dep],
  install: true,
  subdir : 'gi',
  c_args: pyext_c_args + main_c_args + ['-D_INSIDE_PYGOBJECT_']
)

if cairo_dep.found()
  gicairoext = python.extension_module('_gi_cairo', ['pygi-foreign-cairo.c'],
    dependencies : [python_ext_dep, glib_dep, gi_dep, ffi_dep, pycairo_dep, cairo_dep, cairo_gobject_dep, pythoncapi_compat_dep],
    install: true,
    subdir : 'gi',
    c_args: pyext_c_args + main_c_args)
endif

subdir('overrides')
subdir('repository')
